// @flow

const config = {
  google: {
    id: 'UA-106598593-2',
  },
};

export default config;
