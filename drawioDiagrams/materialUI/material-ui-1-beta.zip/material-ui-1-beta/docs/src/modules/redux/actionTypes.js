// @flow

const actionTypes = {
  THEME_CHANGE_PALETTE_TYPE: 'THEME_CHANGE_PALETTE_TYPE',
  THEME_CHANGE_DIRECTION: 'THEME_CHANGE_DIRECTION',
};

export default actionTypes;
