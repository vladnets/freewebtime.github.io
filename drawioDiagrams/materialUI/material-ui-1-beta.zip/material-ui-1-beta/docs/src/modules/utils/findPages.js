// @flow

import { findPages } from './find';

const pages = findPages({
  front: true,
});

export default pages;
