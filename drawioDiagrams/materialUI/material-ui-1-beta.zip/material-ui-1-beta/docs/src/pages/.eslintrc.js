module.exports = {
  rules: {
    'prefer-destructuring': 'error',
  },
};
