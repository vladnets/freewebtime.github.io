---
components: Badge
---

# Badge

Badge generates a small badge to the top-right of its child(ren).

## Simple examples

Two examples of badges containing text, using primary and accent colors. The badge is applied to its children.

{{demo='pages/demos/badges/SimpleBadge.js'}}

