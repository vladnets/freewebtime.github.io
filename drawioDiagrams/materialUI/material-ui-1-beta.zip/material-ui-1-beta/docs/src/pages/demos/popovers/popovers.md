---
components: Popover
---

# Popovers

A `Popover` can be used to display some content on top of another.

## Anchor playground

Use the radio buttons to adjust the `anchorOrigin` and `transformOrigin` positions.

{{demo='pages/demos/popovers/AnchorPlayground.js'}}
