# Community

If you want to stay up to date on the development of Material-UI or to reach out the community, you can follow those resources:

- Chat with us on [gitter](https://gitter.im/callemall/material-ui).
- For help using Material-UI, ask on StackOverflow using the tag
[material-ui](http://stackoverflow.com/questions/tagged/material-ui).
- Follow [@MaterialUI](https://twitter.com/MaterialUI) on twitter.
