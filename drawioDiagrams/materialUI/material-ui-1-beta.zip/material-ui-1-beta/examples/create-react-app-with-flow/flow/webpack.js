declare var module : {
  hot : {
    accept(path:string, callback:() => void): void;
  };
};
