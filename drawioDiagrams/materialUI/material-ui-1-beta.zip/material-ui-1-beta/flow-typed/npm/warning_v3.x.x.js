// flow-typed signature: ff7cc037c6a5f6f7d053669a03581d47
// flow-typed version: b43dff3e0e/warning_v3.x.x/flow_>=v0.15.x

declare module warning {
  declare var exports: (shouldBeTrue: bool, warning: string) => void;
}
