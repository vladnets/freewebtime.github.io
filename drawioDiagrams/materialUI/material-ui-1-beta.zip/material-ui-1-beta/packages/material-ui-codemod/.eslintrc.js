module.exports = {
  rules: {
    'flowtype/require-valid-file-annotation': 'off',
  },
};
