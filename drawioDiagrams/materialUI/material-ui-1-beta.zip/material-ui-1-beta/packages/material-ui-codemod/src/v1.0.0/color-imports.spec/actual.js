import { blue, teal500, fullWhite, fullBlack } from 'material-ui/styles/colors';
import { lightBlue600 as primaryColor, orangeA200 } from 'material-ui/styles/colors';
import * as muiColors from 'material-ui/styles/colors';

let randomColorUsedFromCollection = muiColors.amber100;
console.log(muiColors.transparent);
