import blue from 'material-ui/colors/blue';
import teal from 'material-ui/colors/teal';
import common from 'material-ui/colors/common';
const teal500 = teal['500'];
const fullWhite = common.fullWhite;
const fullBlack = common.fullBlack;
import lightBlue from 'material-ui/colors/lightBlue';
import orange from 'material-ui/colors/orange';
const primaryColor = lightBlue['600'];
const orangeA200 = orange.A200;
import * as muiColors from 'material-ui/colors';

let randomColorUsedFromCollection = muiColors.amber['100'];
console.log(muiColors.common.transparent);
