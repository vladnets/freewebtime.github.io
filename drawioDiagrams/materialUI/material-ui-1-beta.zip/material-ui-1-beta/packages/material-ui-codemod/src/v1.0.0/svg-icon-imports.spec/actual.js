import CheckCircle from 'material-ui/svg-icons/action/check-circle';
import Rotation3D from 'material-ui/svg-icons/action/three-d-rotation';
import Comment from 'material-ui/svg-icons/communication/comment';
const TransferWithinAStation = require('material-ui/svg-icons/maps/transfer-within-a-station');
